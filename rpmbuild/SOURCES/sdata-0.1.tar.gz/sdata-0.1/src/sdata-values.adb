with Ada.Text_IO;
with SData.Config;
with Ada.Strings.Fixed; use Ada.Strings.Fixed;

package body SData.Values is

   ------------------
   -- To_String --
   ------------------
   function To_String (V : Value) return String is
   begin
      case V.Kind is
         when Val_Numeric =>
            declare
               Img : constant String := Float'Image (V.Num_Val);
            begin
               return Trim (Img, Ada.Strings.Both);
            end;
         when Val_Integer =>
            declare
               Img : constant String := Integer'Image (V.Int_Val);
            begin
               return Trim (Img, Ada.Strings.Both);
            end;
         when Val_String =>
            return V.Str_Val (1 .. V.Str_Len);
         when Val_Missing =>
            return ".";
      end case;
   end To_String;

   -------------------------
   -- To_String_Formatted --
   -------------------------
   function To_String_Formatted (V : Value) return String is
   begin
      case V.Kind is
         when Val_Numeric =>
            declare
               package Float_IO is new Ada.Text_IO.Float_IO (Float);
               Img : String (1 .. 100);
               Aft_Count : constant Natural := SData.Config.Print_Digits;
            begin
               Float_IO.Put (Img, V.Num_Val, Aft => Aft_Count, Exp => 0);
               return Trim (Img, Ada.Strings.Both);
            exception
               when others =>
                  return Trim (Float'Image (V.Num_Val), Ada.Strings.Both);
            end;
         when others => return To_String (V);
      end case;
   end To_String_Formatted;

   -------------
   -- Is_True --
   -------------
   function Is_True (V : Value) return Boolean is
   begin
      case V.Kind is
         when Val_Numeric =>
            return V.Num_Val /= 0.0;
         when Val_Integer =>
            return V.Int_Val /= 0;
         when others =>
            return False;
      end case;
   end Is_True;

   ---------
   -- "=" --
   ---------
   function "=" (L, R : Value) return Boolean is
   begin
      if L.Kind /= R.Kind then
         -- Promotion logic for comparison
         if L.Kind = Val_Numeric and R.Kind = Val_Integer then
            return L.Num_Val = Float (R.Int_Val);
         elsif L.Kind = Val_Integer and R.Kind = Val_Numeric then
            return Float (L.Int_Val) = R.Num_Val;
         end if;
         return False;
      end if;

      case L.Kind is
         when Val_Numeric => return L.Num_Val = R.Num_Val;
         when Val_Integer => return L.Int_Val = R.Int_Val;
         when Val_String  =>
            if L.Str_Len /= R.Str_Len then return False; end if;
            return L.Str_Val (1 .. L.Str_Len) = R.Str_Val (1 .. R.Str_Len);
         when Val_Missing => return True;
      end case;
   end "=";

   ---------
   -- "<" --
   ---------
   function "<" (L, R : Value) return Boolean is
   begin
      -- Missing is always smallest
      if L.Kind = Val_Missing then
         return R.Kind /= Val_Missing;
      elsif R.Kind = Val_Missing then
         return False;
      end if;

      if L.Kind = Val_Numeric or L.Kind = Val_Integer then
         declare
            FL : constant Float := (if L.Kind = Val_Numeric then L.Num_Val else Float (L.Int_Val));
            FR : constant Float := (if R.Kind = Val_Numeric then R.Num_Val else Float (R.Int_Val));
         begin
            if R.Kind = Val_Numeric or R.Kind = Val_Integer then
               return FL < FR;
            else
               return True; -- Numeric < String (arbitrary but consistent)
            end if;
         end;
      elsif L.Kind = Val_String then
         if R.Kind = Val_String then
            return L.Str_Val (1 .. L.Str_Len) < R.Str_Val (1 .. R.Str_Len);
         else
            return False; -- String > Numeric
         end if;
      end if;
      return False;
   end "<";

end SData.Values;
